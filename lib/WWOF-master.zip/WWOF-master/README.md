# WWOF

An energy efficient offloading framework for migrating web worker from browser to server

